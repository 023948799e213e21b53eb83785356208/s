local p = {"H", "e", "ll", "o"}
print(table.concat(p))