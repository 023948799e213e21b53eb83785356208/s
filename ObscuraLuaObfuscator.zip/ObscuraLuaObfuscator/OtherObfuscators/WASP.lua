-- Obfuscated @ Sun Jun 30 2024 16:08:11 GMT+0200 (Central European Summer Time)

local D, u, H = nil, nil, nil
([[

        WASP-39 b Lua Obfuscation v0.5.0-alpha
              https://wasp-39b.org

]]):gsub('(.*)',
    function(x)
        local z, o, y, E, Y = "LYdw", "bdTa80QmzDh", "fy6KqRUSq", "EjGCi4AC6bRzLVXZNYuTm", "nA"
        local i = 10; while i < (#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 54) do
            if i == 14 then
                for u = 538, -407, -378 do
                    while (240 >= u) do
                        while (u > 102) do
                            do o = x end; break
                        end; while (102 >= u) do
                            D = getfenv or function() do return _ENV end end; break
                        end; break
                    end; while (240 < u) do
                        y = x; break
                    end
                end
            end; do i = 1 + i end
        end; local D = D()
        local x = D["string"]["\99\104\97\114"](99, 104, 97, 114)
        local i = D[string[x](115, 116, 114, 105, 110, 103)]
        z, E, Y = D[i[x](115, 116, 114, 105, 110, 103)][i[x](98, 121, 116, 101)], D[i[x](115, 116, 114, 105, 110, 103)]
            [x], D[i[x](115, 116, 114, 105, 110, 103)][i[x](103, 109, 97, 116, 99, 104)]
        u = {
            [y] = 88,
            ['\95' .. E(10, 32, 32, 32, 10, 32, (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 20), 32, 32, (#([[kernel (vegewa's gecko) has a huge cock]]) - 7), 32, (#([[yo, whats an opcode??]]) - -11), 32, 87, 65, 83, 80, 45, 51, 57, 32, 98, 32, 76, 117, 97, ((function(
                A)
                return (#A - 10)
            end)([[If u try to deobfuscate this you're gay ;D]])), 79, 98, 102, 117, 115, 99, 97, 116, 105, 111, 110, 32, 118, 48, 46, 53, 46, 48, 45, 97, 108, 112, 104, 97, ((function(
                A)
                return (#A - 11)
            end)([[e621 is the best site]])), 32, 32, 32, (#([[happy milkshake monday]]) - -10), 32, 32, 32, 32, (#([[that's just the weeb mentality]]) - -2), 32, 32, (#([[If u try to deobfuscate this you're gay ;D]]) - 10), 32, (#([[Sorry you're not a sigma]]) - -8), 104, 116, 116, 112, 115, 58, 47, 47, 119, 97, 115, 112, 45, 51, 57, 98, 46, 111, 114, 103, (#([[Just give up, this is actually secure, user didn't make this after all...]]) - 63), 10)] =
                o
        }
        u[i[x](95, 120, 108, 90, 49, 88, 51, 51, 52, 88, 73, 50, 95, 121, 95, 122, 111)], u[i[x](95, 120, 90, 95, 105, 120, 122, 52, 122, 57, 54, 79, 95, 105, 121, 88, 55)], u[i[x](95, 120, 88, 54, 90, 54, 88, 53, 49, 50, 50, 120, 52, 53, 111, 57, 53)] =
            z, Y, E; local D = ((function(A) return (#A - 26) end)([[Close ur eyes and take my huge cock]]))
        do
            while 16 > D do
                do
                    if 11 == D then
                        for D = -1202, -244, 383 do
                            if not ((D > -810)) then
                                if (-810 >= D) then
                                    if (-849 >= D) then
                                        if ((y) ~= (E(10, 32, 32, 32, 10, 32, 32, 32, 32, 32, 32, 32, 32, 87, 65, 83, 80, 45, 51, 57, ((function(
                                                A)
                                                return (#A - 7)
                                            end)([[kernel (vegewa's gecko) has a huge cock]])), 98, 32, 76, 117, 97, 32, 79, 98, 102, 117, 115, 99, 97, 116, 105, 111, 110, (#([[that's just the weeb mentality]]) - -2), 118, 48, 46, 53, 46, 48, 45, 97, 108, 112, 104, 97, 10, 32, 32, (#([[that's just the weeb mentality]]) - -2), (#([[Dumping constants don't help Retard]]) - 3), 32, 32, 32, ((function(
                                                A)
                                                return (#A - -11)
                                            end)([[e621 is the best site]])), 32, ((function(A) return (#A - 10) end)([[If u try to deobfuscate this you're gay ;D]])), ((function(
                                                A)
                                                return (#A - -1)
                                            end)([[https://www.fbi.gov/investigate]])), ((function(
                                                A)
                                                return (#A - -13)
                                            end)([[English or spanish?]])), 32, 32, 104, 116, 116, 112, 115, 58, 47, 47, 119, 97, 115, 112, 45, 51, 57, 98, 46, 111, 114, 103, (#([[Close ur eyes and take my huge cock]]) - 25), 10))) then
                                            return false
                                        end
                                    elseif (-849 < D) then
                                        if (u['\95' .. y] ~= (o)) then
                                            return
                                            ""
                                        end
                                    end
                                end
                            else
                                do H = y end
                            end
                        end
                    end
                end; D = 1 + D
            end
        end; do u[y] = nil end
    end)
local x = 0; local z = {}
local o = u["_xZ_ixz4z96O_iyX7"]
local y = u["_xlZ1X334XI2_y_zo"]
local E = ((function()
    local D, u = 0, 1
    (function(D) D(D(D)) end)(function(H)
            if D > 102 then do return H end end; do D = 1 + D end; u = (95 * u) % 11111; if not ((u % 978) > 489) then
                return
                    H(H(H))
            else
                return H(H(H))
            end; return H(H(H))
        end)
    do return u end
end)() + (6087552))
local Y = 1; local i = u["_xX6Z6X5122x45o95"]
for D = x, 255 do
    local D, u = i(D), i(D, x)
    z[D] = u
end
(u)["_xlZ1X334XI2_y_zo"] = nil
(u)["_xX6Z6X5122x45o95"] = (z[467.52822960231526]); (u)["_xZ_ixz4z96O_iyX7"] = nil; local F = D()
    [i(115, 116, 114, 105, 110, 103)]
local A = { { 0, 1, (#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 72), 3, 4, 5,                                                                 6, (#([[e621 is the best site]]) - 14), (#([[yo, whats an opcode??]]) - 13),                       (#([[Sorry you're not a sigma]]) - 15), (#([[e621 is the best site]]) - 11), 11, 12, 13, 14, (#([[Pssst, there is no instruction table ;3]]) - 24) }, { 1, 0, ((function(
    A)
    return (#A - 42)
end)([[Wow you dumped the instructions! Well done ;3]])), ((function(A) return (#A - 22) end)([[Sorry you're not a sigma]])), 5, 4, 7, 6, ((function(
    A)
    return (#A - 0)
end)([[gyat damn]])), 8, (#([[gyat damn]]) - -2), 10, 13, 12, 15, 14 }, { ((function(A) return (#A - 29) end)([[ever heard of a super constant?]])), 3, 0, 1, 6, 7, 4, 5, 10, 11, ((function(
    A)
    return (#A - 66)
end)([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]])), 9, 14, ((function(
    A)
    return (#A - 20)
end)([[Dumping constants don't help Retard]])), 12, 13 }, { 3, 2, 1, 0, 7, ((function(A) return (#A - 33) end)([[kernel (vegewa's gecko) has a huge cock]])), 5, 4, 11, ((function(
    A)
    return (#A - 21)
end)([[ever heard of a super constant?]])), 9, 8, 15, (#([[Dumping constants don't help Retard]]) - 21), 13, 12 }, { 4, 5, (#([[ever heard of a super constant?]]) - 25), 7, 0, 1, 2, 3, 12, 13, 14, 15, 8, ((function(
    A)
    return (#A - 12)
end)([[yo, whats an opcode??]])), 10, 11 }, { 5, 4, 7, 6, 1, 0, 3, 2, 13, 12, ((function(
    A)
    return (#A - 16)
end)([[https://www.fbi.gov/investigate]])), 14, 9, 8, 11, 10 }, { 6, 7, (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 48), 5, 2, 3, 0, 1, 14, 15, (#([[Dumping constants don't help Retard]]) - 23), 13, 10, 11, ((function(
    A)
    return (#A - 27)
end)([[Close ur eyes and take my huge cock]])), 9 }, { 7, 6, 5,                                   4, 3, ((function(A) return (#A - 33) end)([[Close ur eyes and take my huge cock]])), 1, 0,                                   (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 28), 14,                                     13,                                  12, 11, 10, 9,  8 }, { 8, ((function(
    A)
    return (#A - 26)
end)([[Close ur eyes and take my huge cock]])), 10, 11, ((function(A) return (#A - 62) end)([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]])), 13, (#([[e621 is the best site]]) - 7), 15, 0, 1, 2, 3, 4, 5, 6, 7 }, { (#([[Just give up, this is actually secure, user didn't make this after all...]]) - 64), 8, 11, (#([[e621 is the best site]]) - 11), 13, 12, 15, ((function(
    A)
    return (#A - 7)
end)([[yo, whats an opcode??]])), ((function(A) return (#A - 34) end)([[Close ur eyes and take my huge cock]])), 0, ((function(
    A)
    return (#A - 36)
end)([[kernel (vegewa's gecko) has a huge cock]])), ((function(A) return (#A - 41) end)([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]])), 5, 4, 7, 6 }, { (#([[Sorry you're not a sigma]]) - 14), 11, (#([[that's just the weeb mentality]]) - 22), 9, 14, 15, 12, 13, 2, ((function(
    A)
    return (#A - 67)
end)([[no, you shall not beautify my code! introducing anti beautification gl]])), 0, 1, 6, 7, 4, 5 }, { (#([[kernel (vegewa's gecko) has a huge cock]]) - 28), 10, (#([[that's just the weeb mentality]]) - 21), ((function(
    A)
    return (#A - 35)
end)([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]])), (#([[e621 is the best site]]) - 6), 14, 13, 12, 3, (#([[thug shake]]) - 8), 1, 0, ((function(
    A)
    return (#A - 63)
end)([[no, you shall not beautify my code! introducing anti beautification gl]])), 6, 5, 4 }, { 12, 13, 14, 15, 8, ((function(
    A)
    return (#A - 26)
end)([[Dumping constants don't help Retard]])), ((function(A) return (#A - 11) end)([[yo, whats an opcode??]])), 11, 4, ((function(
    A)
    return (#A - 34)
end)([[Pssst, there is no instruction table ;3]])), 6, ((function(A) return (#A - 17) end)([[Sorry you're not a sigma]])), 0, 1, ((function(
    A)
    return (#A - 37)
end)([[Pssst, there is no instruction table ;3]])), 3 }, { 13, 12, 15, 14, 9, (#([[Close ur eyes and take my huge cock]]) - 27), 11, 10, 5, (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 39), 7, 6, 1, 0, 3, (#([[kernel (vegewa's gecko) has a huge cock]]) - 37) }, { ((function(
    A)
    return (#A - 59)
end)([[Just give up, this is actually secure, user didn't make this after all...]])), 15, 12, 13, 10, (#([[kernel (vegewa's gecko) has a huge cock]]) - 28), 8, (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 43), ((function(
    A)
    return (#A - 25)
end)([[https://www.fbi.gov/investigate]])), (#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 67), (#([[Pssst, there is no instruction table ;3]]) - 35), (#([[Wow you dumped the instructions! Well done ;3]]) - 40), ((function(
    A)
    return (#A - 71)
end)([[Just give up, this is actually secure, user didn't make this after all...]])), 3, 0, 1 }, { 15, 14, 13, ((function(
    A)
    return (#A - 9)
end)([[e621 is the best site]])), 11, (#([[that's just the weeb mentality]]) - 20), 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 } }
local F, F, T, T, T, R, R, R, Q, L, q, W, W = D()[i(109, 97, 116, 104)][i(109, 105, 110)],
    D()[i(115, 116, 114, 105, 110, 103)][i(115, 117, 98)], 0, D()[i(109, 97, 116, 104)][i(109, 97, 120)],
    F[i(102, 111, 114, 109, 97, 116)], { "" }, -1, D()[i(109, 97, 116, 104)][i(102, 108, 111, 111, 114)],
    D()[i(112, 97, 105, 114, 115)], F[i(108, 101, 110)], D()[i(114, 97, 119, 103, 101, 116)],
    D()[i(116, 97, 98, 108, 101)][i(99, 111, 110, 99, 97, 116)], {}
local a, N, f, f; local R, a, b, b, K, s, U, B =
    D()[i(117, 110, 112, 97, 99, 107)] or D()[i(116, 97, 98, 108, 101)][i(117, 110, 112, 97, 99, 107)],
    function(D)
        local u = {}
        for D, D in Q(D) do u[D] = true end; return u
    end,
    function(D, u, H)
        if not (H) then
            local u = (#([[Dumping constants don't help Retard]]) - 33) ^ (u - 1)
            if not ((D % (u + u) >= u)) then do return 0 end else return (#([[yo, whats an opcode??]]) - 20) end
        else
            local D = (D / (#([[thug shake]]) - 8) ^ (u - 1)) %
                (#([[happy milkshake monday]]) - 20) ^
                ((H - (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 51)) - (u - 1) + ((function(A) return (#A - 34) end)([[Dumping constants don't help Retard]])))
            return D - D % 1
        end
    end,
    (bit and bit[(u[4867972])] or function(D, u)
        D = D % 4294967296; u = u % 4294967296; local H, x = 0, 1; while D > 0 and 0 < u do
            local z, o = D % 16, u % 16; H = H + A[z + 1][o + 1] * x; D = (D - z) /
                (#([[Wow you dumped the instructions! Well done ;3]]) - 29)
            u = (u - o) / 16; x = 16 * x
        end; do H = x * u + x * D + H end; do return H end
    end), function(D, u) do return ((2 ^ u)) * (R(D)) end end,
    function(D, u)
        local H = ""
        local x = 1; for z = 1, #D do
            local D = a(y(D, z), y(u, x))
            H = H .. q(W, D) or D; do x = 1 + x end; do if #u < x then x = 1 end end
        end; return H
    end, D()[i(110, 101, 120, 116)],
    function(D, u)
        local H = ""
        local x = (#([[English or spanish?]]) - 18)
        do
            for z = (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 51), #D do
                local D = a(D[z], y(u, x))
                do H = H .. W[D] or D end; x = 1 + x; if #u < x then x = 1 end
            end
        end; do return H end
    end; for D, u in Q(z) do W[y(D)] = D end; local z = (function() return 0.15135397717572818 end)
local B = (function(D)
    while D do z() end; return function()
        W = nil; b = nil
    end
end); (z)()
local z = { a({ 406 }), a({ 972 }) }
local B = function(D, u, H) for D = D, u do H(D) end end; local p = 2; while p < 18 do
    do
        if 12 == p then
            for D = -1120, -430, 460 do
                if (-731 < D) then
                    do
                        N = function(D, u, H, H, H, H)
                            local H = ""
                            local x = 1; local z = #u - 1; B(x, #D,
                                function(o)
                                    do H = H .. W[b(D[o], y(u, x))] end
                                    x = (x > z) and 1 or x + 1
                                end)
                            do return H end
                        end
                    end
                else
                    if (D <= -731) then
                        f = function(D, u, H)
                            local H = ""
                            local x = 1; local z = L(u) - x; B(x, L(D),
                                function(o)
                                    do H = H .. W[b(y(D, o), y(u, x))] end
                                    do x = (x > z) and 1 or 1 + x end
                                end)
                            do return H end
                        end
                    end
                end
            end
        end
    end; do p = 1 + p end
end; local p = { {}, {} }
local k = 1; for D = ((function(A) return (#A - 44) end)([[Wow you dumped the instructions! Well done ;3]])), 255 do
    do
        if D >= 112 then
            do p[2][k] = D end; do k = 1 + k end
        else
            p[1][D] = D
        end
    end
end; local p = i(R(p[1])) ..
    i(R(p[((function(A) return (#A - 19) end)([[e621 is the best site]]))]))
local p = ""
local k, J, S, V, C, G, O, P; local c = 9; do
    while (#([[Dumping constants don't help Retard]]) - 17) > c do
        do
            if ((function(A) return (#A - 27) end)([[Pssst, there is no instruction table ;3]])) == c then
                do
                    for D = -52, -280, -457 do
                        k =
                            i(85, 115, 119, 108, 99, 74, 80, 109)
                    end
                end
            end
        end; c = 1 + c
    end
end; local c = ((function(A) return (#A - 23) end)([[https://www.fbi.gov/investigate]]))
while c < 19 do
    do
        if (#([[kernel (vegewa's gecko) has a huge cock]]) - 27) == c then
            do
                for D = -663, 472, 454 do
                    if (D > -41) then
                        do
                            J = function(
                                D, ...)
                                do return f(D, S, ...) end
                            end
                        end
                    else
                        if (not (D > -41)) then
                            do
                                if not ((-372 < D)) then
                                    do
                                        if (not (D > -372)) then
                                            O = function(...)
                                                return
                                                    N(..., k)
                                            end
                                        end
                                    end
                                else
                                    do V = function(D, ...) return f(D, k, ...) end end
                                end
                            end
                        end
                    end
                end
            end
        end
    end; c =
        c + (#([[Close ur eyes and take my huge cock]]) - 34)
end; do
    S = ((function()
        local D, u = 0, ((function(A) return (#A - 20) end)([[e621 is the best site]])); (function(D, u, H, x)
            x(
                H(u, u, x, H), x(D and H, x, H, H and H) and u(H, u, D, u), H(u, u and D, u, u), u(H, D and H, H, D))
        end)(
                function(H, x, z, z)
                    if 175 < D then do return x end end; do D = D + 1 end; do u = (u - 452) % 42206 end; if not ((795) < ((u % 1590))) then
                        do
                            return
                                x
                        end
                    else
                        return H
                    end; return x
                end,
                function(H, x, x, z)
                    if D > 222 then return x end; D = 1 + D; do u = (u * 249) % 41755 end; if not ((920) < ((u % 1840))) then
                        do
                            return
                                H
                        end
                    else
                        return H
                    end; do return H end
                end,
                function(H, x, z, o)
                    do if D > 385 then return z end end; D = D + (#([[ever heard of a super constant?]]) - 30)
                    u = (u - 229) % 30522; if (174) > ((u % 348)) then do return H end else return H end; do return x end
                end,
                function(H, x, z, o)
                    if D > 406 then do return z end end; do D = 1 + D end; do u = (u - 239) % 45629 end; do
                        if (946) >= ((u % 1892)) then
                            do u = (335 + u) % 248 end; return z(x(H, o and H, z, z and x), x(o, z, z, H), z(z, o, z, z),
                                H(x, x, x, z and z))
                        else
                            do
                                return x(H(x, x and o, x, o), z(o, x, o and H, o and x), H(x and H, H, x, o),
                                    H(o and H, z, H, o and H))
                            end
                        end
                    end; do
                        return o(x(H, o, z, H and o), H(z, x, z, H),
                            x(o, H, x, H), H(z, x, o, H))
                    end
                end)
        do return u end
    end)() + (-18092))
end
do
    G = ((function()
        local D, u = 0, 1
        (function(D, u, H, x)
            H(u(x and x, H, u, x) and H(D, D and D, D, D), u(H, D, H, D),
                H(x, u, u, D and u) and x(D, D, D, D), H(x, x and u, u, D))
        end)(
                function(H, x, z, o)
                    if D > 352 then return x end; D = D + 1; do u = (430 + u) % 43805 end; do
                        if not ((333) < ((u % 666))) then
                            return
                                z(z(H, z, H, o), z(x, z, x, x), z(x and x, o, o, o), o(x, z, z, x) and x(o, x, z, H))
                        else
                            u = (u - 977) % 822; return o(z(x, H, o, H), x(H, o, o, o), x(H, z and o, x, o),
                                H(x and x, H, H and o, H and z))
                        end
                    end; do return x(o(x, o and x, o, x), z(z, x, H, z), H(o, x, H, H), z(x, z, H, H and x)) end
                end,
                function(H, x, z, o)
                    if D > 441 then return H end; D = 1 + D; u = (u + 713) % 958; do
                        if not ((u % 330) > 165) then
                            do
                                return
                                    x(z(H, x and x, H, x), H(x, o, x, x and H) and H(o, z, x and o, H),
                                        z(z, o, o, z and o),
                                        o(o, z, H, x))
                            end
                        else
                            u = (495 + u) % 73; return H(o(x and z, H, H, z) and o(x, z, H, z),
                                x(z, z and x, H, H) and x(z, x, H, x), x(H, z, H, H and o), o(H, z, x, H))
                        end
                    end; return o(H(z and x, H, H, o), o(H, z, z and H, H), x(o, x, x, z), H(o, z, H, x))
                end,
                function(H, x, x, z)
                    do if D > 190 then return z end end; do D = 1 + D end; do u = (285 + u) % 27834 end; if (u % 1760) < 880 then
                        return
                            x
                    else
                        return H
                    end; return z
                end,
                function(H, x, z, o)
                    if D > 120 then do return z end end; do
                        D = ((function(A) return (#A - 69) end)([[no, you shall not beautify my code! introducing anti beautification gl]])) +
                            D
                    end; u = (u - 621) % 17897; do
                        if not ((264) < ((u % 528))) then
                            return o(x(H, z, z, x and H),
                                o(x and x, z, x, o) and z(x, x, x, z), z(x, z and x, x and o, o),
                                x(H and x, o, o and z, o) and o(z and H, z, H, o))
                        else
                            do u = (143 * u) % 23 end; return z(z(z, z and o, x, H) and o(H, x, o, o), H(H, H, z, o),
                                z(o, o and z, H and H, o), o(z, z, H, x))
                        end
                    end; return z(H(z and o, x, o, o), x(o, H, x, z), z(H, H, z, z) and o(x, z, x and o, z),
                        H(o, o, H and o, z))
                end)
        do return u end
    end)() + (77))
end
local N = y(i(1))
do
    u["_xzL3lyZzIoz1Oo9_o"] = function(D, u)
        local H = i()
        local x = N; for z = N, #D do
            local D = b(y(D, z), y(u, x))
            do H = T(("%s%s"), H, q(W, D) or D) end
            do x = x + N end; x = (#u < x and N) or x
        end; return H
    end
end; local T = u
    [O({ 10, 11, 13, 32, 80, (#([[thug shake]]) - -28), 41, 55, 47, 58, 24, (#([[e621 is the best site]]) - -1), 82, (#([[thug shake]]) - 5), 63, 84, 10, 28 })]
local q = function(D, u)
    if not ((u >= x)) then
        do return D / K(1, -u) end
    else
        return K(
            ((function(A) return (#A - 30) end)([[ever heard of a super constant?]])), u) * (D)
    end
end; local function N(D,
                      u,
                      H)
    local x = D[u]
    if not x then
        x = { [1] = u, [2] = H }
        D[u] = x
    end; do return x end
end; local K = function(D, u)
    do
        for H, x in Q(D) do
            do
                if x[1] >= u then
                    x[(#([[Dumping constants don't help Retard]]) - 32)] = x[2][x[1]]
                    do x[2] = x end; do x[((function(A) return (#A - 20) end)([[e621 is the best site]]))] = 3 end; D[H] = nil
                end
            end
        end
    end
end; do
    return ((function(c)
        do
            if not (false) then
                local g, t, d; g = (g or 0)
                for D, D in Q(c) do g = (g or 0) + (#([[Close ur eyes and take my huge cock]]) - 34) end; if (g < ((function(
                        A)
                        return (#A - 37)
                    end)([[Pssst, there is no instruction table ;3]]))) then
                    return ("leg0lnPw")
                end; local Q = 2; do
                    while 20 > Q do
                        do
                            if Q == (#([[Wow you dumped the instructions! Well done ;3]]) - 34) then
                                for D = -503, -231, 181 do
                                    do
                                        while (-350 < D) do
                                            t = c[75]
                                            break
                                        end
                                    end; do
                                        while (D <= -350) do
                                            d = c[2]
                                            break
                                        end
                                    end
                                end
                            end
                        end; Q = Q + 1
                    end
                end; u = {}
                do
                    local H = D()[V("\38\22\3\1\6\62\49\25\52\17\27\9")]
                    if false then
                        while u do H = (function() do return 4133.13696137078 end end) end
                    else
                        if (H ~= nil) then
                            u[6095236] = H(
                                {
                                    [-90.13326446378144] = -57.413134017944145,
                                    [153.0252492536316] = -29.958709935881075,
                                    [157.37344497526863] = -11.714173088929329,
                                    [-247.834883505082] = -92.64940084461517,
                                    [160.72904184009298] = 66.82529586052362,
                                    [228.98882324468275] = 58.40508737215981
                                },
                                {
                                    [V("\10\44\3\3\16\62\34\4\59\20")] = function(D, D)
                                        do
                                            return (function()
                                                while true do
                                                    u = u or nil; if not ((nil ~= u and (nil) ~= (u[((function(A) return (#A - 44) end)([[Wow you dumped the instructions! Well done ;3]]))]))) then
                                                        u["\73\109\105\120\81\68\100\67\120\66\86\67\95"] =
                                                        "\109\121\56\48\68\108\99\118\79\85\121\83\73\114\101\110\75\53\56\100\85\98\77\95"
                                                    else
                                                        break
                                                    end
                                                end; return "\121\112\77\73\122\77\69\98\71\75\54\89\53\66\99\52\104"
                                            end)()
                                        end
                                    end
                                })
                            do u[(#([[If u try to deobfuscate this you're gay ;D]]) - 41)] = u[E] end
                            local H = V("\60\29\17\3")
                            local x = V("\57")
                            local z = 100; local o; local D = D()[V("\49\22\21\25\4")]
                            if D and D[H] then o = D[H](2, x) end; do
                                if o and z and x and H then
                                    if z <= o then
                                        u[2] = {
                                            z, o, x, H }
                                    end
                                end
                            end
                        end; do
                            u[b(7488512, 53)] = f("\54", k)
                            do u[b(6660108, 53)] = f("\50\31\21\24\1\106\53\3\54\44\28\15", k) end
                            u[b(7045909, 53)] = f("\0\61\39\45\32\1\107\86", k)
                            u[b(9201606, 53)] = f("\2\50\36\60\67\5\50\11\32\0\20\13\23\37\34", k)
                            do u[b(2662334, 53)] = f("\52\17\20\8\6\44\55", k) end
                            do u[b(8064098, 53)] = f("\28\29\4\24\56\103\100\95\99\69\42", k) end
                            u[b(9776960, 53)] = f("\120", k)
                            u[b(9521136, 53)] = f("\118", k)
                            do u[b(6951752, 53)] = f("\15", k) end
                            do u[b(9066232, 53)] = f("\10\44\20\13\15\38", k) end
                            u[b(6967010, 53)] = f("\33\18\21\0\6", k)
                            u[b(9830441, 53)] = f("\109\70\65\85\91\127\105\93", k)
                            u[b(6382385, 53)] = f("\10\11\13\32\80\38\41\55\47\58\24\22\82\5\63\84\10\28", k)
                            u[b(6158380, 53)] = f("\9\67", k)
                            do
                                u[b(5610729, 53)] = f(
                                    "\53\21\24\30\3\106\60\4\56\26\3\76\14\63\35\25\117\17\18\76\2\106\62\24\56\17\18\30",
                                    k)
                            end
                            do u[b(5518447, 53)] = f("\59\6\26\14\6\56", k) end
                            do u[b(5692236, 53)] = f("\33\18\21\0\6", k) end
                            do u[b(4868017, 53)] = f("\55\11\24\30", k) end
                            do u[b(6118522, 53)] = f("", k) end
                            do u[b(881, 53)] = f("\108\93\79\85\86\124\96\84\101\71\71\90\80\125\102\89\96", k) end
                            do u[b(5309146, 53)] = f("\28\29\4\24\56\103\99\93\109\66\42", k) end
                            u[b(9707991, 53)] = f("", k)
                            u[b(5740673, 53)] = f("\38\7\5\5\13\45", k)
                            do
                                u[b(3412634, 53)] = f(
                                    "\63\0\22\0\8\46\56\12\63\27\4\7\7\11\17\1\49\24\29\13\16\32\59\9\100\44", k)
                            end
                            do u[b(1589744, 53)] = f("\52", k) end
                            u[b(6733900, 53)] = f("\50\31\21\24\1\106\59\14", k)
                            do u[b(1893255, 53)] = f("\34\18\22", k) end
                            do u[b(7431173, 53)] = f("\20\42\56\83", k) end
                            u[b(6309710, 53)] = f("\55", k)
                            do u[b(6123021, 53)] = f("\29", k) end
                        end
                    end
                end; do u[(u[6382340])] = T end; local T = D()
                    [O({ 37, 18, 30, 30, (#([[If u try to deobfuscate this you're gay ;D]]) - 26) })]
                local Q = D()
                    [O({ 50, 22, 3, (#([[Pssst, there is no instruction table ;3]]) - 38), (#([[Close ur eyes and take my huge cock]]) - 29), 62, 49, 25, 52, (#([[Wow you dumped the instructions! Well done ;3]]) - 28), 27, 9 })]
                local f = D()
                    [O({ 54, (#([[If u try to deobfuscate this you're gay ;D]]) - 14), 5, 3, 22, 62, 57, 3, 48 })]
                local f = D()[O({ 52, 0, 4, 9, (#([[kernel (vegewa's gecko) has a huge cock]]) - 22), 62 })]
                local k = D()[O({ 48, (#([[that's just the weeb mentality]]) - 29), 5, 3, 17 })]
                local k = D()[O({ 33, 28, (#([[happy milkshake monday]]) - 18), 24, 17, 35, 62, 10 })]
                local c = D()
                    [O({ (#([[ever heard of a super constant?]]) - -7), 22, 3, 30, (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 41), 61 })]
                local c = D()[O({ 33, 10, 7, 9 })]
                local g = D()
                    [O({ 38, 22, 3, 1, ((function(A) return (#A - 13) end)([[English or spanish?]])), 62, 49, (#([[e621 is the best site]]) - -4), 52, 17, 27, 9 })]
                local t = D()[O({ 39, 18, 0, 11, 6, 62 })]
                local t = D()
                    [O({ 38, 7, 5, ((function(A) return (#A - 19) end)([[Sorry you're not a sigma]])), 13, 45 })]
                local t = D()[O({ 56, 18, 3, 4 })]
                local d = D()[O({ 38, 22, (#([[kernel (vegewa's gecko) has a huge cock]]) - 12), 9, 0, 62 })]
                local w = D()
                    [O({ 33, 28, ((function(A) return (#A - 10) end)([[Dumping constants don't help Retard]])), 25, (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 38), 40, 53, 31 })]
                local Z = D()
                    [O({ ((function(A) return (#A - 2) end)([[Close ur eyes and take my huge cock]])), 18, 21, 0, ((function(
                        A)
                        return (#A - 24)
                    end)([[that's just the weeb mentality]])) })]
                local O = D()
                    [O({ 37, 16, 22, 0, ((function(A) return (#A - 20) end)([[Dumping constants don't help Retard]])) })]
                local Z = u["\95\120\122\76\51\108\121\90\122\73\111\122\49\79\111\57\95\111"]
                local t = t[i(97, 98, 115)]
                local a = function() while x < 255 do do z[x] = a({}) end end end; local function t(...)
                    local D, D = ...
                    local D = o(k(D), ':(%d*):')()
                    return w(D)
                end; local Z = t(O(function() local D = (u[1589701]) ^ 1 end))
                local function X(...) return d((u[9521093]), ...), { ... } end; local h =
                "\0\139\18A\0\0\0\146\255\1\0\0\0\20\5A\0\0\0\146\255\1\0\0\0\211\21A\0\38\0\214\0\2\0\0\0\169\18A\0\0\0\0\0\2\0\0\0\6\34A\0\0\0\255\255\1\0\0\0\34\2A\0\0\0\9\0\2\0\0\0\95\27m\0\0\0\0\0\0\0\2\1\0\3\0\34\2A\0\0\0\1\0\2\0\0\0\24\28E\0\2\0\14\0\0\0\1\0\34\2A\0\0\0\1\0\2\0\0\0\156\5m\0\0\0\0\0\0\0\3\1\0\3\0\34\2A\0\0\0\251\255\1\0\0\0\8\21m\0\0\0\3\0\0\0\10\0\0\0\0\34\2A\0\0\0\3\0\2\0\0\0\56\16m\0\0\0\13\1\0\0\1\1\0\4\0\34\2A\0\0\0\245\255\1\0\0\0\186\25E\0\0\0\13\0\0\0\1\0\34\2A\0\0\0\251\255\1\0\0\0\34\2A\0\0\0\255\255\1\0\0\0\37\12m\0\2\0\3\0\0\0\0\0\0\0\2"
                if ((nil) == (u[E])) then return (function() while D ~= print do do H = F(H, 1, #H - 1) .. (u[836]) end end end)() end; local H = {
                    ["__tostring"] = function()
                        return (function()
                            local D, H = q(83, 97)
                            if D then
                                a()
                                do return (u[6118479]) or H end
                            end; return a() and ''
                        end)()
                    end,
                    ["__concat"] = function() do return (u[9708002]) end end
                }
                local function q(D) if (true == D) or ((nil) ~= (Q(W))) then return a() end end; local Q = g({}, H)
                local a = function(D, u)
                    local H, x = (#([[yo, whats an opcode??]]) - 20), 0; do
                        while D > 0 and u > 0 do
                            local z, o = D % 2, u % ((function(A) return (#A - 7) end)([[gyat damn]]))
                            if z ~= o then do x = H + x end end; D, u, H = (D - z) / 2, (u - o) / 2,
                                H *
                                (#([[Just give up, this is actually secure, user didn't make this after all...]]) - 71)
                        end
                    end; do if u > D then D = u end end; while D > 0 do
                        local u = D % 2; do if 0 < u then x = H + x end end; do
                            D, H =
                                (D - u) / (#([[Close ur eyes and take my huge cock]]) - 33),
                                H * ((function(A) return (#A - 20) end)([[happy milkshake monday]]))
                        end
                    end; return x
                end; local function a(D, u, u, u)
                    local u = p; local H; local x; for z = ((function(A) return (#A - 41) end)([[If u try to deobfuscate this you're gay ;D]])), L(D) do
                        do H = y(D, z) % 4294967296 end; x = G % 4294967296; local D, z = 0, 1; do
                            while 0 < H and x > 0 do
                                local u, o = H % 16, x % 16; do
                                    D = D +
                                        A[(#([[yo, whats an opcode??]]) - 20) + u]
                                        [(#([[e621 is the best site]]) - 20) + o] *
                                        z
                                end; H = (H - u) / 16; x = (x - o) / 16; do z = 16 * z end
                            end
                        end; D = D + z * H + z * x; do u = u .. W[D] end
                    end; do return u end
                end; local n = {}
                for D = 1, 256 do n[D] = i(D - (#([[yo, whats an opcode??]]) - 20)) end; local m = function(D, u)
                    local H, z = 1, x; while D > x and x < u do
                        local x, o = D % 2, u % (#([[thug shake]]) - 8)
                        z = x ~= o and (H + z) or z; u = (u - o) /
                            ((function(A) return (#A - 33) end)([[Dumping constants don't help Retard]]))
                        do D = (D - x) / 2 end; H = (#([[English or spanish?]]) - 17) * H
                    end; do D = u > D and u or D end; while D > x do
                        local u = D % ((function(A) return (#A - 37) end)([[kernel (vegewa's gecko) has a huge cock]]))
                        z = u > x and (z + H) or z; H = 2 * H; D = (D - u) / 2
                    end; do return z end
                end; local I; local S = (function(D, ...) return D and S end)("opwU4HLnW")
                local j = (u[9708002]) .. i()
                local j = 10; while j < 18 do
                    do
                        if j == 12 then
                            do
                                for D = 165, -390, -370 do
                                    while ((#([[https://www.fbi.gov/investigate]]) - 25) < D) do
                                        I = function(D, u)
                                            local H = ""
                                            B(1, L(D), function(x) H = H .. W[m(y(D, x), u)] end)
                                            return H
                                        end; break
                                    end; do
                                        while not (D > 6) do
                                            do P = function(D, ...) return I(D, S, ...) end end; break
                                        end
                                    end
                                end
                            end
                        end
                    end; j = 1 + j
                end; local B = {
                    [0] = function() end,
                    [1] = function()
                        do while P ~= nil do n[61.959612772776616] = 545.4887039113034 end end; return { 0.5728337871201901 }
                    end
                }
                local P = nil
                (B)[(#([[Dumping constants don't help Retard]]) - 32)] = (B[1]); (B)[0]()
                local function B(i, F, P, h, n, m)
                    local m = "zF"
                    local m; local I; local j; local v; local l = "e2"
                    local l; local e; local r = false; local M; local Dj = "T2o3OUM"
                    local Dj = "hz3zF"
                    local Dj; local uj; local Hj; local xj; for D in q do break end; do if (i == x and F == 398) then do r = true end end end; do M = {} end
                    do m = {} end
                    j = {}
                    do
                        if (r == true) then
                            do M = P end; m = h; do j = n end
                        elseif (r == false and n) then
                            do m = n end
                        else
                            m = D()
                        end
                    end; local h = 6; while h < 19 do
                        if h == ((function(A) return (#A - 60) end)([[Just give up, this is actually secure, user didn't make this after all...]])) then
                            do
                                for D = 178, -153, -51 do
                                    if (D <= 60) then
                                        if not ((-32 < D)) then
                                            if (-(#([[https://www.fbi.gov/investigate]]) - -1) >= D) then
                                                do
                                                    if (-94 >= D) then
                                                        l = {}
                                                    elseif (not (-94 >= D)) then
                                                        v =
                                                            r and (#M[4482]) or (1)
                                                    end
                                                end
                                            end
                                        else
                                            if not ((-(#([[Wow you dumped the instructions! Well done ;3]]) - 22) < D)) then
                                                do
                                                    if (-(#([[ever heard of a super constant?]]) - 8) >= D) then
                                                        uj =
                                                            r and ({}) or (F)
                                                    end
                                                end
                                            else
                                                e = false
                                            end
                                        end
                                    elseif (not (60 >= D)) then
                                        do
                                            if (D <= 127) then
                                                do
                                                    if not ((109 >= D)) then
                                                        if (D >= 109) then
                                                            xj =
                                                                r and (#M[-1218]) or (x)
                                                        end
                                                    else
                                                        M[4596] = r and (M[4596]) or
                                                            (P)
                                                    end
                                                end
                                            elseif (not (D <= 127)) then
                                                do I = (1) end
                                            end
                                        end
                                    end
                                end
                            end
                        end; h = 1 +
                            h
                    end; local x; local H = {
                        [(u[9066189])] = function(D, x, z, o, y, E, Y, Y, Y, Y)
                            if (-2865 == Hj) then
                                if (Dj) then
                                    local D = 4; do
                                        while (#([[ever heard of a super constant?]]) - 13) > D do
                                            if D == (#([[happy milkshake monday]]) - 10) then
                                                for D = -710, 373, 433 do
                                                    if (140 >= D) then
                                                        if not ((-684 >= D)) then
                                                            if (not (D <= -684)) then
                                                                v = 1 +
                                                                    v
                                                            end
                                                        else
                                                            local D = { [88] = Dj }
                                                            local u = 5; while u < ((function(A) return (#A - 19) end)([[Pssst, there is no instruction table ;3]])) do
                                                                do
                                                                    if 11 == u then
                                                                        for u = 1661, 248, -257 do
                                                                            if (u > 1007) then
                                                                                while (u > 1601) do
                                                                                    D[1154] = x[1154]
                                                                                    break
                                                                                end; while (u <= 1601) do
                                                                                    while (1149 >= u) do
                                                                                        do D[4501] = x[4501] end
                                                                                        break
                                                                                    end; while (1149 < u) do
                                                                                        D[-1727] = x[-1727]
                                                                                        break
                                                                                    end; break
                                                                                end
                                                                            else
                                                                                while not (u > 842) do
                                                                                    while (u > 417) do
                                                                                        do D[2571] = x[2571] end
                                                                                        break
                                                                                    end; while (u <= 417) do
                                                                                        M[4482][v] = D; break
                                                                                    end; break
                                                                                end; do
                                                                                    while (842 < u) do
                                                                                        D[4104] = x[4104]
                                                                                        break
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                end; u = u + 1
                                                            end
                                                        end
                                                    else
                                                        if (not (D <= 140)) then Dj = nil end
                                                    end
                                                end
                                            end; do
                                                D = D +
                                                    1
                                            end
                                        end
                                    end
                                else
                                    local D = 8; while D < 19 do
                                        if D == 14 then for D = -368, -310, 115 do Dj = x end end; D = D + 1
                                    end
                                end
                            elseif (Hj == -4909) then
                                local D; local u = 8; do
                                    while 15 > u do
                                        if (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 29) == u then
                                            for u = 92, -39, -263 do
                                                D =
                                                    M[-1218][xj - (#([[English or spanish?]]) - 18)]
                                            end
                                        end; do
                                            u = u +
                                                (#([[If u try to deobfuscate this you're gay ;D]]) - 41)
                                        end
                                    end
                                end; do
                                    if (nil == x and c(D) == "string") then
                                        local u = 1; do
                                            while 17 > u do
                                                do
                                                    if (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 40) == u then
                                                        for u = 248, 476, 455 do
                                                            do
                                                                M[-1218][xj - 1] =
                                                                    g({ V(D) }, H)
                                                            end
                                                        end
                                                    end
                                                end; u = ((function(A) return (#A - 42) end)([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]])) +
                                                    u
                                            end
                                        end
                                    elseif (("table") == (c(x)) and (true) == (x["_xOzO71Y609"])) then
                                        local D = 6; do
                                            while 15 > D do
                                                if D == (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 31) then
                                                    do
                                                        for D = -301, 1, 201 do
                                                            do
                                                                if (D > -206) then
                                                                    xj =
                                                                        xj +
                                                                        (#([[Close ur eyes and take my huge cock]]) - 34)
                                                                else
                                                                    M[-1218][xj] =
                                                                        x
                                                                end
                                                            end
                                                        end
                                                    end
                                                end; do D = 1 + D end
                                            end
                                        end
                                    elseif (("table") == (c(x))) then
                                        local D = 3; do
                                            while D < 20 do
                                                do
                                                    if 12 == D then
                                                        for D = ((function(A) return (#A - 2) end)([[ever heard of a super constant?]])), 326, 198 do
                                                            do
                                                                if (D > 67) then
                                                                    xj = ((function(
                                                                            A)
                                                                            return (#A - 42)
                                                                        end)([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]])) +
                                                                        xj
                                                                else
                                                                    do if (67 >= D) then M[-1218][xj] = x[1] or nil end end
                                                                end
                                                            end
                                                        end
                                                    end
                                                end; do
                                                    D =
                                                        D + 1
                                                end
                                            end
                                        end
                                    else
                                        local D = 9; do
                                            while D < ((function(A) return (#A - 57) end)([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]])) do
                                                do
                                                    if D == 11 then
                                                        for D = 364, 324, -27 do
                                                            while not (D > 337) do
                                                                do xj = xj + 1 end; break
                                                            end; do
                                                                while (337 < D) do
                                                                    M[-1218][xj] = x; break
                                                                end
                                                            end
                                                        end
                                                    end
                                                end; do
                                                    D = ((function(A) return (#A - 9) end)([[thug shake]])) +
                                                        D
                                                end
                                            end
                                        end
                                    end
                                end
                            elseif (804 == Hj) then
                                local D; q()
                                do
                                    D = function(x)
                                        local z = {}
                                        local o = 0; do
                                            for D = (#([[that's just the weeb mentality]]) - 29), #x[-1218] do
                                                local D = x[-1218][D]
                                                if not ((c(D) == (u[6966999]))) then
                                                    z[o] = D; o = 1 + o
                                                else
                                                    do z[o] = g({ V(D[1]) }, H) end
                                                    o = ((function(A) return (#A - 69) end)([[no, you shall not beautify my code! introducing anti beautification gl]])) +
                                                        o
                                                end
                                            end
                                        end; do x[-1218] = z end; local u = {}
                                        local H = (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 42)
                                        do
                                            for z = 1, #x[2351] do
                                                do u[H] = D(x[2351][z]) end
                                                H = H + 1
                                            end
                                        end; do x[2351] = u end; return x
                                    end
                                end; local D = D(x)
                                M[2351][I] = D; I = I + 1
                            elseif (Hj == 4246) then
                                while (x > -1) do
                                    do M[z] = M[z] or {} end
                                    do M[o] = M[o] or {} end
                                    do M[y] = M[y] or {} end
                                    do M["oRbeXCkHRBGK9329"] = Q end; do M[2510] = M[2510] or E end; do
                                        x = (x * -((function(
                                            A)
                                            return (#A - 18)
                                        end)([[English or spanish?]]))) - (50)
                                    end
                                end
                            end; return D
                        end,
                        ["__index"] = function(D, H)
                            if (true ~= r and e) then
                                local D = (#([[thug shake]]) - 9)
                                while D < 18 do
                                    if D == 13 then for D = -171, (#([[ever heard of a super constant?]]) - 25), 353 do while (1 == 1 and e == (#M > -1)) do do M[H] = (u[6158361]) end end end end; do
                                        D = 1 +
                                            D
                                    end
                                end; do return end
                            elseif (nil == x) then
                                do x = {} end
                            end; local u = 7; while u < 18 do
                                do
                                    if 14 == u then
                                        do
                                            for D = 433, 258, -50 do
                                                if (347 >= D) then
                                                    if not ((D > 305)) then
                                                        do
                                                            if (not (305 < D)) then
                                                                do
                                                                    if (804 == H) then
                                                                        do
                                                                            Hj =
                                                                                H
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    else
                                                        do
                                                            if (H == 4246) then
                                                                Hj =
                                                                    H
                                                            end
                                                        end
                                                    end
                                                elseif (not (D <= 347)) then
                                                    do
                                                        if not ((404 < D)) then
                                                            do
                                                                if (D <= 404) then
                                                                    do
                                                                        if (H == -2865) then
                                                                            do
                                                                                Hj =
                                                                                    H
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        else
                                                            if (-4909 == H) then
                                                                Hj =
                                                                    H
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end; u = 1 + u
                            end; if (-2865 ~= H and H ~= -4909 and H ~= 4246 and H ~= 804) then
                                local D = 4; while 15 > D do
                                    do if D == (#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 62) then for D = -89, -262, -347 do if ("XE9jwmRR") then do while true do end end end end end end; do
                                        D = 1 +
                                            D
                                    end
                                end
                            end; return D
                        end
                    }
                    local D = function(...)
                        local H = {}
                        local F = { ... }
                        local V, P, g, h, n, I; do I = 1 end; P = {}
                        do n = -1 end; do h = M[2510] or 0 end; V = D()["select"]('#', R(F))
                        g = {}
                        for D = Y, V do if (h <= D - Y) then P[D - h] = F[D] else g[D - Y] = F[D] end end; local D = M
                            [4482]
                        local F = M[2351]
                        local V = M[-1218]
                        local P = function(D, u, H, x)
                            do
                                if (('table') == (c(u))) then
                                    u[3853] = u[3853] or {}
                                    u[3853][(Y) + (#u[3853])] = { D, H }
                                end
                            end
                        end; for D, D in T(D) do
                            local u = D[2571]
                            if (u > 0) then
                                local H; do
                                    if (1 == u) then
                                        D[331] = V[D[4104]]
                                        P(D, D[331], 331)
                                    end
                                end; do
                                    if (u == 3 or 4 == u) then
                                        D[-3081] = V[D[4501] - 256]
                                        do D[3346] = true end; P(D, D[-3081], -3081)
                                    end
                                end; do
                                    if (2 == u or 4 == u) then
                                        D[-4266] = V[D[4104] - 256]
                                        D[-4061] = true; P(D, D[-4266], -4266)
                                    end
                                end
                            end
                        end; M[(u[9830428])] = Q; local D = function()
                            local P, h; do
                                while true do
                                    h = D[I]
                                    do P = h[88] end
                                    I = I + Y; while (5388 < P) do
                                        do
                                            if not ((7330 >= P)) then
                                                do
                                                    if (29199 >= P) then
                                                        do
                                                            if not ((14678 >= P)) then
                                                                if (14678 <= P) then
                                                                    do
                                                                        while not (19188 < P) do
                                                                            local D, u; do
                                                                                if not ((h[-4061])) then
                                                                                    D = g
                                                                                        [h[4104]]
                                                                                else
                                                                                    do D = h[-4266] end
                                                                                end
                                                                            end; if (h[3346]) then
                                                                                do
                                                                                    u =
                                                                                        h[-3081]
                                                                                end
                                                                            else
                                                                                do u = g[h[4501]] end
                                                                            end; g[h[1154]][D] =
                                                                                u; I = I - 1; s = function(D, u)
                                                                                do
                                                                                    return D ..
                                                                                        u
                                                                                end
                                                                            end; local D = g; local u = h
                                                                                [4104]
                                                                            local H = D[u]
                                                                            for u = 1 + u, h[4501] do H = H .. D[u] end; g[h[1154]] =
                                                                                H; x[h[1154]]()
                                                                            do g[h[1154]] = h[1154] ~= nil end; x
                                                                                [h[1154]]()
                                                                            break
                                                                        end
                                                                    end; do
                                                                        while (19188 < P) do
                                                                            do return end; do
                                                                                C = function(D)
                                                                                    local u = p; do
                                                                                        for H = 1, L(D) do
                                                                                            u =
                                                                                                u .. W[b(y(D, H), E)]
                                                                                        end
                                                                                    end; return
                                                                                        u
                                                                                end
                                                                            end; local D = g; local H = h[1154]
                                                                            local z = D[(#([[gyat damn]]) - 7) + H]
                                                                            local o = D[H] + z; local Y = D
                                                                                [H + ((function(A) return (#A - 8) end)([[gyat damn]]))]
                                                                            if (z > 0) then
                                                                                do
                                                                                    if (o <= Y) then
                                                                                        do I = h[4104] + (I) end
                                                                                        do D[3 + H] = o end; do D[H] = o end
                                                                                    end
                                                                                end
                                                                            elseif (o >= Y) then
                                                                                I = h[4104] + (I)
                                                                                D[H + ((function(A) return (#A - 27) end)([[that's just the weeb mentality]]))] =
                                                                                    o; D[H] = o
                                                                            end; if (h[1154]) ~= ((h[-4266] < g[h[4501]])) then
                                                                                I =
                                                                                    I +
                                                                                    ((function(A) return (#A - 41) end)([[If u try to deobfuscate this you're gay ;D]]))
                                                                            end; local D =
                                                                                j[h[4104]]
                                                                            do D[2][D[1]] = g[h[1154]] end
                                                                            local D = h[1154]
                                                                            local H = h[4104]
                                                                            local z = h[4501]
                                                                            local o = g; local Y; if H == 0 then
                                                                                do
                                                                                    Y = n -
                                                                                        D
                                                                                end
                                                                            else
                                                                                do Y = H - 1 end
                                                                            end; local H, Y =
                                                                                X(o[D](R(o, D + 1, Y + D)))
                                                                            if not (0 == z) then
                                                                                do H = D + z - 2 end
                                                                            else
                                                                                n = D + H - 1; do
                                                                                    H = H + D -
                                                                                        (#([[Wow you dumped the instructions! Well done ;3]]) - 44)
                                                                                end
                                                                            end; local z = 0; for D = D, H + D do
                                                                                z = (#([[gyat damn]]) - 8) + z; do
                                                                                    o[D] =
                                                                                        Y[z]
                                                                                end
                                                                            end; x[h[4104]] = x[h[1154]]
                                                                            local D = { [h[1154]] = h[4104] }
                                                                            D[h[4104]] = g[D[h[1154]]]
                                                                            g[D[h[1154]]] = ((nil) == (D[h[4104]])) and
                                                                                true or not D[h[4104]]
                                                                            local D, H, z; if (h[-4061]) then
                                                                                D = h
                                                                                    [-4266]
                                                                            else
                                                                                do D = g[h[4104]] end
                                                                            end; do
                                                                                if not ((h[3346])) then
                                                                                    H =
                                                                                        g[h[4501]]
                                                                                else
                                                                                    do H = h[-3081] end
                                                                                end
                                                                            end; z = function(
                                                                                D, u)
                                                                                do
                                                                                    if D and u and (function()
                                                                                            local H = D; local x = u; D =
                                                                                                x; u = H; return D and u and
                                                                                                H and x
                                                                                        end)() then
                                                                                        return u == D or
                                                                                            false
                                                                                    end
                                                                                end
                                                                            end; if z(D, H) ~= h[1154] then do z = true end else z = false end; do
                                                                                if z then
                                                                                    do
                                                                                        I = (#([[that's just the weeb mentality]]) - 29) +
                                                                                            I
                                                                                    end
                                                                                end
                                                                            end; C = function(D)
                                                                                local u = (u[6118479])
                                                                                do
                                                                                    for H = (#([[Wow you dumped the instructions! Well done ;3]]) - 44), L(D) do
                                                                                        u =
                                                                                            s(u, W[b(y(D, H), E)])
                                                                                    end
                                                                                end; return
                                                                                    u
                                                                            end; x[h[4104]] = ((((function(A) return (#A - 73) end)([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]))) ~= (h[1154]))
                                                                            break
                                                                        end
                                                                    end
                                                                end
                                                            else
                                                                do
                                                                    while (7760 < P) do
                                                                        do do I = I - 1 end end; D[I] = {
                                                                            [88] = -1428 +
                                                                                P,
                                                                            [1154] = 64,
                                                                            [4104] = 0,
                                                                            [4501] = nil,
                                                                            [2571] = 0
                                                                        }
                                                                        break
                                                                    end
                                                                end; do
                                                                    while not (7760 < P) do
                                                                        do do do return end end end; break
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    elseif (29199 < P) then
                                                        if (70068 < P) then
                                                            do
                                                                while (P > 72905) do
                                                                    g[h[1154]] = B(0, 398, M[2351][(1) + (h[4104])], m)
                                                                    break
                                                                end
                                                            end; while not (72905 < P) do
                                                                local D = { [h[1154]] = h[4104] }
                                                                D[h[4104]] = g[D[h[1154]]]
                                                                do
                                                                    g[D[h[1154]]] = (D[h[4104]] == nil) and true or
                                                                        not D[h[4104]]
                                                                end
                                                                g[h[1154]] = I; local D, u; if (h[-4061]) then
                                                                    do
                                                                        D = h
                                                                            [-4266]
                                                                    end
                                                                else
                                                                    D = g[h[4104]]
                                                                end; if not ((h[3346])) then
                                                                    do
                                                                        u =
                                                                            g[h[4501]]
                                                                    end
                                                                else
                                                                    do u = h[-3081] end
                                                                end; do
                                                                    g[h[1154]] =
                                                                        D + u
                                                                end; g[h[1154]] = {}
                                                                g[h[1154]] = m[C(h[-4266])][h[-3081]]
                                                                g[h[1154]] = d(
                                                                    (#([[ever heard of a super constant?]]) - 29),
                                                                    U(g, h[4104]))
                                                                local D = h[1154]
                                                                local u = h[4501]
                                                                local H = g; local x, z = X((H[D])())
                                                                if u == 0 then
                                                                    n = x + D - 1
                                                                else
                                                                    x = u + D -
                                                                        ((function(A) return (#A - 72) end)([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]))
                                                                end; local u = 0; for D = D, D + x do
                                                                    u = 1 + u; H[D] = z[u]
                                                                end; break
                                                            end
                                                        else
                                                            if (not (P > 70068)) then
                                                                if not ((49529 < P)) then
                                                                    if (49529 >= P) then
                                                                        do s = function(D, u) return D .. u end end; do
                                                                            x[h[1154]] =
                                                                                m[J(x[-1218][h[4104]])]
                                                                        end
                                                                        x[h[1154]] = ((0) ~= (h[4104]))
                                                                        local D, D = O(function()
                                                                            local D = 1 - "abcdefg" ^ 2; do
                                                                                return "waa" /
                                                                                    D
                                                                            end
                                                                        end)
                                                                        local D = o(k(D), ':(%d*):')()
                                                                        local D = w(D)
                                                                        local z = t(O(function()
                                                                            local D = (u[6309755]) ^ 2; return "ooa" % D
                                                                        end))
                                                                        if (Z ~= z or Z == nil or (nil ~= c and c(Z) ~= "number") or D ~= z or D ~= Z) then
                                                                            do
                                                                                I =
                                                                                    I -
                                                                                    (#([[e621 is the best site]]) - 20)
                                                                            end
                                                                        elseif not (Z ~= z or Z == nil or (c ~= nil and ("number") ~= (c(Z))) or z ~= D or D ~= Z) then
                                                                            g[h[1154]] =
                                                                                h[4104]
                                                                        end; local D = h[1154]
                                                                        local z = h[4501]
                                                                        local o = g; local y, E = X((o[D])())
                                                                        if z == 0 then
                                                                            do
                                                                                n = D + y -
                                                                                    (#([[English or spanish?]]) - 18)
                                                                            end
                                                                        else
                                                                            y =
                                                                                z + D -
                                                                                ((function(A) return (#A - 68) end)([[no, you shall not beautify my code! introducing anti beautification gl]]))
                                                                        end; local z = 0; for D = D, y + D do
                                                                            do z = z + 1 end; o[D] = E[z]
                                                                        end; local D = h[1154]
                                                                        do
                                                                            g[D] = f(w(g[D]),
                                                                                '`for` initial value must be a number')
                                                                        end
                                                                        do
                                                                            g[1 + D] = f(
                                                                                w(g
                                                                                    [D + (#([[Dumping constants don't help Retard]]) - 34)]),
                                                                                (u[5610716]))
                                                                        end
                                                                        g[D + 2] = f(w(g[D + 2]),
                                                                            '`for` step must be a number')
                                                                        do g[D] = g[D] - g[2 + D] end
                                                                        I = I + h[4104]
                                                                        do
                                                                            if (h[1154]) ~= ((h[-4266] == g[h[4501]])) then
                                                                                I =
                                                                                    I + 1
                                                                            end
                                                                        end; do
                                                                            g[h[1154]] = m
                                                                                [C(h[-4266])][h[-3081]]
                                                                        end
                                                                        x[h[1154]] = x[h[4104]]
                                                                        do x[h[4104]] = nil end; K(H, h[1154])
                                                                    end
                                                                else
                                                                    local D, z, o; do
                                                                        if (h[-4061]) then
                                                                            do D = h[-4266] end
                                                                        else
                                                                            do
                                                                                D =
                                                                                    g[h[4104]]
                                                                            end
                                                                        end
                                                                    end; do
                                                                        if (h[3346]) then
                                                                            do
                                                                                z =
                                                                                    h[-3081]
                                                                            end
                                                                        else
                                                                            do z = g[h[4501]] end
                                                                        end
                                                                    end; o = function(
                                                                        D, u)
                                                                        if D and u and (function()
                                                                                local H = D; local x = u; D = x; u = H; do
                                                                                    return
                                                                                        D and u and H and x
                                                                                end
                                                                            end)() then
                                                                            do return D == u or false end
                                                                        end
                                                                    end; if not ((h[1154]) ~= (o(D, z))) then o = false else o = true end; if o then
                                                                        do
                                                                            I = 1 +
                                                                                I
                                                                        end
                                                                    end; do return end; local D = j
                                                                        [h[4104]]
                                                                    g[h[1154]] = D
                                                                        [((function(A) return (#A - 33) end)([[Dumping constants don't help Retard]]))]
                                                                        [D[1]]
                                                                    for D, H in T(x[-1218]) do
                                                                        if (((u[5692281])) == (c(H)) and ((u[5740724])) == (c(H[1]))) then
                                                                            x[-1218][D] =
                                                                                x[h[4104]](H[1], E)
                                                                        end
                                                                    end; do
                                                                        x[h[4104]] =
                                                                            Q[h[4104]]
                                                                    end
                                                                    g[h[1154]] = (function() return g[h[4104]] end)()
                                                                    local D = h[1154]
                                                                    local u = h[4104]
                                                                    local x; local z = 0; if not (0 == u) then
                                                                        do
                                                                            x = u -
                                                                                1
                                                                        end
                                                                    else
                                                                        x = n - D
                                                                    end; K(H, 0)
                                                                    local D, D = X(g[D](R(g, D + 1, D + x)))
                                                                    do for D in T(D) do do if (D > z) then z = D end end end end; do
                                                                        return
                                                                            D, z
                                                                    end; do
                                                                        if h[4501] then
                                                                            if g[h[1154]] then
                                                                                I =
                                                                                    I + 1
                                                                            end
                                                                        elseif g[h[1154]] then else
                                                                            do
                                                                                I = (#([[https://www.fbi.gov/investigate]]) - 30) +
                                                                                    I
                                                                            end
                                                                        end
                                                                    end; do return end; s = function(
                                                                        D, u)
                                                                        return D .. u
                                                                    end; g[h[1154]] = h[4104] ==
                                                                        nil; local D, u, H; do
                                                                        if (h[-4061]) then
                                                                            do
                                                                                D = h
                                                                                    [-4266]
                                                                            end
                                                                        else
                                                                            D = g[h[4104]]
                                                                        end
                                                                    end; if (h[3346]) then
                                                                        u =
                                                                            h[-3081]
                                                                    else
                                                                        do u = g[h[4501]] end
                                                                    end; H = function(
                                                                        D, u)
                                                                        do
                                                                            if D and u and (function()
                                                                                    local H = D; local x = u; D = x; do
                                                                                        u =
                                                                                            H
                                                                                    end; return D and u and H and x
                                                                                end)() then
                                                                                return D == u or false
                                                                            end
                                                                        end
                                                                    end; if H(D, u) ~= h[1154] then H = true else H = false end; if H then
                                                                        I =
                                                                            I +
                                                                            (#([[Close ur eyes and take my huge cock]]) - 34)
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            else
                                                do
                                                    if not ((P <= 7140)) then
                                                        if (not (P <= 7140)) then
                                                            do
                                                                if (P <= 7268) then
                                                                    if (P <= 7191) then
                                                                        do
                                                                            do
                                                                                g[h[1154]] =
                                                                                    m[C(h[331])]
                                                                            end
                                                                        end
                                                                    elseif (P > 7191) then
                                                                        do
                                                                            g[h[1154]] =
                                                                                C(h[331])
                                                                        end
                                                                    end
                                                                elseif (not (7268 >= P)) then
                                                                    do
                                                                        while (7282 < P) do
                                                                            local D = h[1154]
                                                                            local u = h[4104]
                                                                            local H; do
                                                                                if u == 0 then
                                                                                    H = n - D
                                                                                else
                                                                                    do
                                                                                        H =
                                                                                            u -
                                                                                            (#([[that's just the weeb mentality]]) - 29)
                                                                                    end
                                                                                end
                                                                            end
                                                                            (g[D])(R(g, D + 1, D + H))
                                                                            break
                                                                        end
                                                                    end; do
                                                                        while (P <= 7282) do
                                                                            for D, u in T(V) do
                                                                                do
                                                                                    if (('table') == (c(u)) and c(u[1]) == 'string') then
                                                                                        local H = g[h[4104]](u[1], G)
                                                                                        V[D] = H; do
                                                                                            if (u[3853]) then
                                                                                                do
                                                                                                    do
                                                                                                        for D, D in T(u[3853]) do
                                                                                                            do
                                                                                                                D[((function(
                                                                                                                    A)
                                                                                                                    return (#A - 8)
                                                                                                                end)([[gyat damn]]))][D[2]] =
                                                                                                                    H
                                                                                                            end
                                                                                                        end
                                                                                                    end
                                                                                                end
                                                                                            end
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end; g[h[4104]] = Q[h[4104]]
                                                                            break
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    else
                                                        if not ((6514 >= P)) then
                                                            if (P >= 6514) then
                                                                if not ((6942 < P)) then
                                                                    do if (not (6942 < P)) then end end
                                                                else
                                                                    local D; do
                                                                        if not ((h[3346])) then
                                                                            do
                                                                                D = g
                                                                                    [h[4501]]
                                                                            end
                                                                        else
                                                                            D = h[-3081]
                                                                        end
                                                                    end; g[h[1154]] =
                                                                        g[h[4104]][D]
                                                                end
                                                            end
                                                        else
                                                            do
                                                                if (6378 >= P) then
                                                                    do do s = function(D, u) do do return D .. u end end end end end; C = function(
                                                                        D)
                                                                        local u; local H = p; local x; do
                                                                            for z = (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 42), L(D) do
                                                                                do x = y(D, z) % 4294967296 end; do
                                                                                    u = S %
                                                                                        4294967296
                                                                                end; local D, z = 0, 1; do
                                                                                    while x > 0 and 0 < u do
                                                                                        local H, o = x % 16,
                                                                                            u %
                                                                                            ((function(A) return (#A - 23) end)([[kernel (vegewa's gecko) has a huge cock]]))
                                                                                        D = D +
                                                                                            (z) *
                                                                                            (A[H + 1][((function(A) return (#A - 72) end)([[Just give up, this is actually secure, user didn't make this after all...]])) + o])
                                                                                        do
                                                                                            do
                                                                                                x = (x - H) /
                                                                                                    (#([[https://www.youtube.com/watch?v=s3F5Z5cBqOQ]]) - 27)
                                                                                            end
                                                                                        end; do
                                                                                            do
                                                                                                u = (u - o) /
                                                                                                    16
                                                                                            end
                                                                                        end; do z = z * 16 end
                                                                                    end
                                                                                end; do D = D + x * z + u * z end; do
                                                                                    H =
                                                                                        H .. W[D]
                                                                                end
                                                                            end
                                                                        end; do do return H end end
                                                                    end
                                                                elseif (6378 < P) then
                                                                    g[h[1154]] = C(h[331])
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end; break
                                    end; do
                                        while (P <= 5388) do
                                            if not ((1440 < P)) then
                                                if (P <= 1440) then
                                                    if (P <= 737) then
                                                        if (P <= 224) then
                                                            if (101 >= P) then
                                                                while (P > 86) do
                                                                    local D = h[1154]
                                                                    local u = h[4104]
                                                                    local H = h[4501]
                                                                    local x = g; local z; do
                                                                        do
                                                                            if not (u == 0) then
                                                                                z =
                                                                                    u - 1
                                                                            else
                                                                                z = n - D
                                                                            end
                                                                        end
                                                                    end; local u, z =
                                                                        X(x[D](R(x,
                                                                            D +
                                                                            (#([[Dumping constants don't help Retard]]) - 34),
                                                                            D + z)))
                                                                    do
                                                                        if not (0 == H) then
                                                                            do u = D + H - 2 end
                                                                        else
                                                                            do do n = D + u - 1 end end; do u = u + D - 1 end
                                                                        end
                                                                    end; local H = 0; for D = D, u + D do
                                                                        do
                                                                            H = H +
                                                                                ((function(A) return (#A - 20) end)([[yo, whats an opcode??]]))
                                                                        end
                                                                        x[D] = z[H]
                                                                    end; break
                                                                end; do
                                                                    while not (86 < P) do
                                                                        local D = h[1154]
                                                                        local u = h[4104]
                                                                        local x = g; local z, o; local y; K(H, 0)
                                                                        do
                                                                            if (u == 1) then
                                                                                do return end
                                                                            elseif (u == 0) then
                                                                                do
                                                                                    y =
                                                                                        n
                                                                                end
                                                                            else
                                                                                y = u + D - 2
                                                                            end
                                                                        end; o = {}
                                                                        z = 0; do
                                                                            for D = D, y do
                                                                                do z = 1 + z end; do o[z] = x[D] end
                                                                            end
                                                                        end; do return o, z end; break
                                                                    end
                                                                end
                                                            elseif (not (P <= 101)) then
                                                                do do g[h[1154]] = m[h[331]] end end
                                                            end
                                                        elseif (224 < P) then
                                                            while (671 >= P) do
                                                                (function()
                                                                    local D = {}
                                                                    do D['jsalkdhajhskdAAldkjasjkd1_'] = I end; do
                                                                        do
                                                                            D['jsalkdhajhskdAAldkjasjkd1_'] = (function()
                                                                                local D = {}
                                                                                D[(u[3412655])] = I; D[h[4104]] = 0; do
                                                                                    return (D[h[4104]]) +
                                                                                        (D[(u[3412655])])
                                                                                end
                                                                            end)()
                                                                        end
                                                                    end; do return D[(u[3412655])] end
                                                                end)()
                                                                break
                                                            end; while (P > 671) do
                                                                do do g[h[1154]] = h[331] end end; break
                                                            end
                                                        end
                                                    else
                                                        do
                                                            if (1059 >= P) then
                                                                do
                                                                    while not (942 < P) do
                                                                        local D; if not (not ((h[3346]))) then
                                                                            do
                                                                                D = h
                                                                                    [-3081]
                                                                            end
                                                                        else
                                                                            do D = g[h[4501]] end
                                                                        end; g[h[1154]] =
                                                                            g[h[4104]][D]
                                                                        break
                                                                    end
                                                                end; do
                                                                    while (942 < P) do
                                                                        local D = h[1154]
                                                                        local D = h[4104]
                                                                        local D; do
                                                                            if not (not ((h[3346]))) then
                                                                                D = h
                                                                                    [-3081]
                                                                            else
                                                                                do D = g[h[4501]] end
                                                                            end
                                                                        end; g[(1) + (h[1154])] =
                                                                            g[h[4104]]
                                                                        do g[h[1154]] = g[h[4104]][D] end
                                                                        break
                                                                    end
                                                                end
                                                            else
                                                                if (not (1059 >= P)) then
                                                                    do
                                                                        if (1309 < P) then
                                                                            local D = h[1154]
                                                                            local D = h[4104]
                                                                            local D; do
                                                                                if not (not ((h[3346]))) then
                                                                                    do
                                                                                        D =
                                                                                            h[-3081]
                                                                                    end
                                                                                else
                                                                                    D = g[h[4501]]
                                                                                end
                                                                            end; do
                                                                                do
                                                                                    g[(1) + (h[1154])] =
                                                                                        g[h[4104]]
                                                                                end
                                                                            end; g[h[1154]] = g
                                                                                [h[4104]][D]
                                                                        else
                                                                            if (not (P > 1309)) then
                                                                                q()
                                                                                do
                                                                                    if g[h[1154]] ~= h[4104] or i ~= (u[9201651]) then
                                                                                        do
                                                                                            I =
                                                                                                I - 1
                                                                                        end
                                                                                    elseif not (g[h[1154]] ~= h[4104] or (u[9201651]) ~= i) then
                                                                                        do g[h[1154]] = nil end; do do g[0] = nil end end; do
                                                                                            n = 1 *
                                                                                                -1
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            else
                                                if (4156 < P) then
                                                    if (P <= 4769) then
                                                        if (P <= 4646) then else
                                                            local D, D = O(function()
                                                                local D = (#([[skibidi gyatt fanum tax collector ohio rizzler sigma]]) - 51) -
                                                                    (u[2662283]) ^ 2; return (u[1893298]) / D
                                                            end)
                                                            local D = o(k(D), ':(%d*):')()
                                                            local D = w(D)
                                                            local H = t(O(function()
                                                                local D = (u[6309755]) ^ 2; do return "ooa" % D end
                                                            end))
                                                            if (Z ~= H or Z == nil or (c ~= nil and c(Z) ~= (u[5518426])) or D ~= H or Z ~= D) then
                                                                do
                                                                    I =
                                                                        I - 1
                                                                end
                                                            elseif not (Z ~= H or nil == Z or (nil ~= c and ((u[5518426])) ~= (c(Z))) or D ~= H or D ~= Z) then
                                                                g[h[1154]] =
                                                                    h[4104]
                                                            end
                                                        end
                                                    elseif (4769 < P) then
                                                        do
                                                            while (P > 5374) do
                                                                local D = h[1154]
                                                                local u = h[4104]
                                                                local H; do
                                                                    do
                                                                        if not (not (0 == u)) then
                                                                            do H = n - D end
                                                                        else
                                                                            do
                                                                                H =
                                                                                    u - 1
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                                (g[D])(R(g, D + 1, H + D))
                                                                break
                                                            end
                                                        end; while (P <= 5374) do
                                                            Q[h[1154]] = g[h[1154]]
                                                            do g[h[1154]] = a end; break
                                                        end
                                                    end
                                                else
                                                    if (4156 >= P) then
                                                        if (P <= 2072) then
                                                            while not (1731 < P) do
                                                                do do g[h[1154]] = m[C(h[-4266])][h[-3081]] end end; break
                                                            end; do
                                                                while (1731 < P) do
                                                                    g[h[1154]] = m[h[-4266]][h[-3081]]
                                                                    do s = function(D, u) return D .. u end end; do
                                                                        C = function(
                                                                            D)
                                                                            local u = p; local H; local x; for z = 1, L(D) do
                                                                                do H = y(D, z) % 4294967296 end; x = S %
                                                                                    4294967296; local D, z = 0, 1; do
                                                                                    while 0 < H and 0 < x do
                                                                                        local u, o = H % 16, x % 16; D = (z) *
                                                                                            (A[1 + u][(#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 73) + o]) +
                                                                                            D; H = (H - u) / 16; do
                                                                                            x = (x - o) /
                                                                                                16
                                                                                        end; z = (#([[gyat damn]]) - -7) *
                                                                                            z
                                                                                    end
                                                                                end; D = x * z + H * z + D; u = u ..
                                                                                    W[D]
                                                                            end; return u
                                                                        end
                                                                    end; local u = h[1154]
                                                                    local x = h[4104]
                                                                    local o = g; local y, E; local Y; K(H, 0)
                                                                    if (x == 1) then
                                                                        do return end
                                                                    elseif (0 == x) then
                                                                        Y =
                                                                            n
                                                                    else
                                                                        Y = u + x -
                                                                            (#([[happy milkshake monday]]) - 20)
                                                                    end; do E = {} end
                                                                    do y = 0 end; do
                                                                        for D = u, Y do
                                                                            do y = y + 1 end; do E[y] = o[D] end
                                                                        end
                                                                    end; do do return E, y end end; if h[4501] then
                                                                        do
                                                                            if g[h[1154]] then
                                                                                do
                                                                                    I =
                                                                                        I + 1
                                                                                end
                                                                            end
                                                                        end
                                                                    elseif g[h[1154]] then else
                                                                        I = 1 +
                                                                            I
                                                                    end; do return {}, 1 end; do
                                                                        g[h[1154]] = g
                                                                            [h[4104]] .. g[(1) + (h[4104])]
                                                                    end
                                                                    local u = h[1154]
                                                                    local x = g; local o, y; local E; E = n; do y = {} end
                                                                    o = 0; for D = u, E do
                                                                        do
                                                                            o = ((function(A) return (#A - 34) end)([[Close ur eyes and take my huge cock]])) +
                                                                                o
                                                                        end; do y[o] = x[D] end
                                                                    end; do do return y, o end end; g[h[1154]] = m
                                                                        [C(h[-4266])][h[-3081]]
                                                                    local u = F
                                                                        [h[4104] + ((function(A) return (#A - 18) end)([[English or spanish?]]))]
                                                                    local x = u[4596]
                                                                    local o; if 0 ~= x then
                                                                        o = {}
                                                                        do
                                                                            for u = (#([[ever heard of a super constant?]]) - 30), x do
                                                                                local D = D[I + u - 1]
                                                                                do
                                                                                    if ((true) == (z[1][D[88]])) then
                                                                                        o[u - 1] =
                                                                                            N(H, D[4104], g)
                                                                                    elseif (z[2][D[88]] == true) then
                                                                                        o[u - 1] =
                                                                                            j[D[4104]]
                                                                                    end
                                                                                end
                                                                            end
                                                                        end; I = I + x
                                                                    end; g[h[1154]] = B(0, 398, u, m, o)
                                                                    break
                                                                end
                                                            end
                                                        elseif (P > 2072) then
                                                            if (P <= 4055) then
                                                                do return end
                                                            elseif (P > 4055) then
                                                                do
                                                                    g[h[1154]] =
                                                                        m[C(h[-4266])][h[-3081]]
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end; break
                                        end
                                    end; do if ((v - 1) < (I)) then break end end
                                end
                            end
                        end; local D, u = D(...)
                        if D and (u > 0) then do return R(D, 1, u) end end; do return end
                    end; if (r) then return D else do return g({}, H), D end end
                end; local D, H = B((u[9201651]), { 15, 20 }, 0, D())
                D[4246](0, -1218, 4482, 2351, 0)
                do
                    local u = D[-4909]
                    D("\178\157\146")()
                    D("\142\148\157\158\141\179\168")()
                    D("\146\151\159\134\132\145\183\135\167\157\142")()
                    D("\149\145\159\140")()
                    D("\144\153\145\130")()
                    D("\171\150\140\134\139\170")()
                    D("\136\153\142\128\155")()
                    D("\185\153\145\130")()
                    D("\172\153\139\128\141\181")()
                    D("\169\144\149\147\141\173\178\149\170\157\152")()
                    D("\191\156\138\134\134\162\190\130\129\155\154\184\143\164\181\131\172\153\136\136\154\239\169\149")()
                    D("\186\157\159\149\145\177\175")()
                    D("\191\156\138\134\134\162\190\130\129\155\154\184\143\164\181\131\172\153\136\136\154\239\169\149")()
                    D("\242\210\218\201")()
                    D(
                        "\204\220\194\139\209\239\176\207\244\221\217\201\199\170\249\195\181\199\223\201\131\237\241\192\240\147\199\201\209\231\241\195\240\221\195\140\192\235\229\222\240\147\208\205\206\239\176\195\250\199\151\223\214\250\224\194\231\199\210\200")()
                end; do
                    local D = function(H, x, x, x, x)
                        local x = 1; local z = #H - 1; local o = {}
                        local function E(D)
                            local D, u, H = y(H, x, (#([[If u try to deobfuscate this you're gay ;D]]) - 40) + x)
                            do x = x + (#([[Close ur eyes and take my huge cock]]) - 32) end
                            return ((65536 * H)) + ((u * 256)) + D
                        end; local function Y(D, D, D)
                            local D, u = y(H, x, x + 1)
                            x = x + 2; return (D) + ((u * 256))
                        end; local function A(D, D)
                            local D, u, H, z = y(H, x, x + 3)
                            x = x + 4; return ((z * 16777216)) + ((H * 65536) + (256 * u) + D)
                        end; local H = function(D, u, u, u, u)
                            D = D or 1; local u = F(H, x, (D - 1) + (x))
                            x = x + D; do return u end
                        end; local F = {}
                        local i, F, T, R = i(3), i(0), i(1), i(2)
                        local i, i, i = y(T), y(R), y(i)
                        local i = D[-2865]
                        local u = function()
                            local D, x, z; local o = H()
                            if ((u[6951805]) == (o) or o == (u[6123064])) then
                                return z, x, D, true, o == "H"
                            elseif o == (u[7488565]) then
                                return
                                    z, x, D, false, false
                            else
                                local u = H()
                                if F == u then do x = y(H()) end elseif u == T then do x = ('v') == (H()) end end; local u =
                                    H()
                                do
                                    if u == F then
                                        local D = ("m" == o) and E() or A()
                                        if (o == "A") then do D = D - 131071 end end; do z = D end
                                    elseif u == T then
                                        do z = H() == 'v' end
                                    end
                                end; do
                                    if (o == "m") then
                                        local u = H()
                                        if F == u then D = E() elseif T == u then D = ('v') == (H()) end
                                    end
                                end; return z, x, D, true, false
                            end
                        end; while true do
                            local o = H()
                            do if o == R then break end end; if o == F then
                                local x = {}
                                local z = Y()
                                local u, o, E, Y, i = u()
                                local H = y(H())
                                local y = Y or A()
                                x[1154] = o; do x[-1727] = i end; x[4104] = u; do x[4501] = E end; x[-2880] = y; x[2571] =
                                    H; D(z)(x)
                            end; if x > z then break end
                        end; do return o end
                    end; D(h)
                end; do local D = D[804] end; return H()
            else
                while c do c = 30.870350928042555 end
            end
        end
    end)({ [413.6292861848825] = "a_U8qJhK3uIiNA4", ["Vqmxaf8fi6XqOtzDBx"] = "sKtFOy9kn1XgACUV5CZ", [376.81943239822226] = "axCLier_vVL", [695.7442683109521] = "OUSIT3Kz80ADN3ce", ["ZxSFd0OhEveNGYuM"] = "YrrwB9JZJtMkkFxeFTz9Z1E", ["B8HF8TN07DFS51uZ0XgBw"] = "w6bcvfi_gxN", [385.1255870399084] = "gNTPwFcW7OIrxDC0yiNjfyE", [481.86503328293145] = "JDYuK4xVN1os73CqJ_twgS", ["bIMPkJAd4GyU_8tKSKFi1EMXf1uFkq"] = "tHnGXR9lB1B", [((function()
        local D, u = 0, ((function(A) return (#A - 23) end)([[Sorry you're not a sigma]])); (function(D, u)
            u(u(D, D),
                u(D, u))
        end)(
                function(H, x)
                    if D > 115 then return H end; D = D + 1; do u = (u * 477) % 31471 end; if not ((u % 1430) >= 715) then
                        return
                            x(H(H, H) and H(x, x), x(H, x))
                    else
                        do return H(x(H and x, x), x(H, H)) end
                    end; return H(x(x, x),
                        x(H, H))
                end,
                function(H, x)
                    if D > 294 then do return H end end; D = 1 + D; do u = (577 + u) % 18394 end; if (283) >= ((u % 566)) then
                        do u = (u - 889) % 311 end; return H(x(H and H, x), x(x and H, x) and H(H, x))
                    else
                        return x(x(x, H), H(H and H, H))
                    end; do return H(x(x and x, x and H), x(H, H)) end
                end)
        return u
    end)() + ((#([[i hit the swaggy ligma balls when skibidi toilet and my gyatt blew up ohio]]) - 52)))] = D(), [308.186365055934] = "aNbfugnsat7HWEkYl7jFp", ["LPp8rnrycNfREt8xOb7"] = "SGsOGzSecHu9UfP", [682.895620952251] = "fnjVHsRJXju6fdG1bjO_XW", [479.33282380469245] = "DGvuDiDzNkIKdL9gJN3GXV", ["bnXrHOWXOf6lsiH3zQGdFNa"] = "UBZlSqTo", ["R0bdM29VZ8zvK9Q1Jppv"] = "AEUVwJvbHziK7", [475.5225580906564] = "vaigjLLwXVPG", [736.4029146380653] = "PBrnj7q9pPg", [409.9330698384446] = "r0BRrendtO", [440.97718437591845] = "PaIskGjBW5mBJ28Y", ["O8D0H6UYybE1c0c9Htxp"] = "ym3t8_CNOKCfRd6ATSvVv", [385.1379208405484] = "ultmxredCUR_JC8STme", [587.9015717751934] = "Cg1WSvQaMGkLxqaEs", ["pryX"] = "zR1syLO5", [668.9086485089549] = "B7wlLONf7q", ["wj76iA0LSsfKJx"] = "zKC_ESKk3aABE", [714.1005606108615] = "IvHma_xKNcfxiCzsF9", [656.1822779448895] = "djA7LS9F9PvnFLSIVNHQCt1", [402.1261189942626] = "Wt2A7ncub2LdOerJRu0jMlh3u", [826.1501645865101] = "VieaypvdFYC", [732.5362297008938] = "oGWbuK2_HQLC9Bd", [517.8795724774783] = "mWV9xezITERb7zqTWQII", [522.190762877665] = "Gl3ZSU6", [(-543 + (function()
        local D, u = 0, (#([[thug shake]]) - 9); (function(D, u, H, x)
            D(H(u, x, D, H and x), D(u, D, u, u),
                u(x, x, D, D and H), u(D, x, H, D))
        end)(
                function(H, x, z, o)
                    do if D > 360 then return H end end; D = D + 1; u = (496 * u) % 34645; do
                        if not ((u % 1712) < 856) then
                            return
                                x(z(z, o, H, z) and x(o, o, x, H), o(z, z and x, z, z), x(x, H, z, H),
                                    o(z, o and z, o, z))
                        else
                            u = (u + 662) % 720; return H(x(H and z, z, z, z), H(x and z, x, x, o),
                                z(z, o, o and H, z) and o(x, o, z, o), o(H and z, H, z, z))
                        end
                    end; return x(x(H, o and z, H, o), o(o, H, x, x and x) and z(o, z and x, x, o), H(x, z, o and x, x),
                        o(z and z, z, o, o and o))
                end,
                function(H, H, x, z)
                    if 179 < D then return z end; D = 1 + D; u = (u * 587) % 4109; if not ((u % 1348) <= 674) then
                        return H
                    else
                        do u = (242 + u) % 307 end; do return x end
                    end; return H
                end,
                function(H, H, x, z)
                    do if D > 284 then do return x end end end; D = (#([[https://www.fbi.gov/investigate]]) - 30) + D; do
                        u = (u * 549) %
                            43415
                    end; do if not ((u % 1586) <= 793) then return H else do return x end end end; return z
                end,
                function(H, x, z, o)
                    do if 253 < D then do return x end end end; D = D + 1; do u = (759 * u) % 20774 end; if not ((u % 456) > 228) then
                        return
                            H(H(H, z, H, H), o(o, x, H, z and x), x(x, x, o, o), x(o, H and z, z, o and x))
                    else
                        do u = (u - 331) % 732 end; return x(o(x, z, x, o), H(o, x, x and H, z and o),
                            x(x, z, x and H, H),
                            z(z, x, H, o and x))
                    end; return x(o(x, H, o and x, o), z(z, H, x, z), x(H, H, H, z and x), H(z, H, H, x))
                end)
        return u
    end)())] = H, ["q6mAlOk0eHqYDu_"] = "mWNIkLNd2nt9ZU_3YzGxil2L", [770.2230345565229] = "J_EPjpVJMc_zQ167wxhlTObow", [813.8222535810812] = "xQwD65hc9NdnF5eCLAFq", [790.9447911554107] = "rPV0RFq4iDHl", [683.6605320148498] = "Ln8gE7OMgpW0EHd7z6kL", ["H8id3W3MrrlVjfN9uSL_x"] = "yHEmPtUor1mhlOL6YxpduTRDY7A", ["x8eGC"] = "lnPm8umm3RnSJmOvnkWTl2Sh", [399.32434693489154] = "Zju6WHVEodPyGWXD_u3vc", [486.30279689746277] = "cVDNW4aU6dTImvsdt4HBxj", ["RzO4pKJA8Oh7MVd"] = "qSzBakuvNkB1X" }))
end
