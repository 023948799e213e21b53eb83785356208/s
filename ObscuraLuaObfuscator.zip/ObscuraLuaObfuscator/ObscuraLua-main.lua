package.path = package.path .. ';./?.lua'
local cli = require("cli")