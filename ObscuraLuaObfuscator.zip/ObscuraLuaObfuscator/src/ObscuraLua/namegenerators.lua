return {
	Mangled  		  		 = require("ObscuraLua.namegenerators.mangled");
	MangledShuffled  		 = require("ObscuraLua.namegenerators.mangled_shuffled");
	Il 		  		  		 = require("ObscuraLua.namegenerators.Il");
	Number 		  		  	 = require("ObscuraLua.namegenerators.number");
	Confuse  		  		 = require("ObscuraLua.namegenerators.confuse");
}