--[[

Created by User319183
Private obfuscation solution for lua & luau
Visit: https://obscuralua.replit.app

--]]


print("Hello, World!")
-- FREE/BASIC SECURTITY: 
	-- lua ./cli.lua --preset Basic --LuaU ./script.lua
-- HIGH/STRONG SECURTITY:
	-- lua ./cli.lua --preset Strong --LuaU ./script.lua

-- Minify: 
	-- lua ./cli.lua --preset Minify --LuaU ./script.lua
-- lua script.obfuscated.lua